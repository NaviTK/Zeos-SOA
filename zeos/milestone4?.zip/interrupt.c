/*
 * interrupt.c -
 */
#include <types.h>
#include <interrupt.h>
#include <segment.h>
#include <hardware.h>
#include <io.h>
#include <devices.h>

#include <zeos_interrupt.h>

void keyboard_handler();
void clock_handler();
void pagefault_handler();
void writeMSR(unsigned long msr, unsigned long value);
void syscall_handler_sysenter();

Gate idt[IDT_ENTRIES];
Register    idtR;

int zeos_ticks = 0;

char char_map[] =
{
  '\0','\0','1','2','3','4','5','6',
  '7','8','9','0','\'','�','\0','\0',
  'q','w','e','r','t','y','u','i',
  'o','p','`','+','\0','\0','a','s',
  'd','f','g','h','j','k','l','�',
  '\0','�','\0','�','z','x','c','v',
  'b','n','m',',','.','-','\0','*',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0','\0','\0','\0','\0','\0','7',
  '8','9','-','4','5','6','+','1',
  '2','3','0','\0','\0','\0','<','\0',
  '\0','\0','\0','\0','\0','\0','\0','\0',
  '\0','\0'
};

void setInterruptHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE INTERRUPTION GATE FLAGS:                          R1: pg. 5-11  */
  /* ***************************                                         */
  /* flags = x xx 0x110 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}

void setTrapHandler(int vector, void (*handler)(), int maxAccessibleFromPL)
{
  /***********************************************************************/
  /* THE TRAP GATE FLAGS:                                  R1: pg. 5-11  */
  /* ********************                                                */
  /* flags = x xx 0x111 000 ?????                                        */
  /*         |  |  |                                                     */
  /*         |  |   \ D = Size of gate: 1 = 32 bits; 0 = 16 bits         */
  /*         |   \ DPL = Num. higher PL from which it is accessible      */
  /*          \ P = Segment Present bit                                  */
  /***********************************************************************/
  Word flags = (Word)(maxAccessibleFromPL << 13);

  //flags |= 0x8F00;    /* P = 1, D = 1, Type = 1111 (Trap Gate) */
  /* Changed to 0x8e00 to convert it to an 'interrupt gate' and so
     the system calls will be thread-safe. */
  flags |= 0x8E00;    /* P = 1, D = 1, Type = 1110 (Interrupt Gate) */

  idt[vector].lowOffset       = lowWord((DWord)handler);
  idt[vector].segmentSelector = __KERNEL_CS;
  idt[vector].flags           = flags;
  idt[vector].highOffset      = highWord((DWord)handler);
}


void setIdt()
{
  /* Program interrups/exception service routines */
  idtR.base  = (DWord)idt;
  idtR.limit = IDT_ENTRIES * sizeof(Gate) - 1;
  
  set_handlers();

  /* ADD INITIALIZATION CODE FOR INTERRUPT VECTOR */
  
  setInterruptHandler(14, pagefault_handler, 0);
  setInterruptHandler(32, clock_handler, 0);
  setInterruptHandler(33, keyboard_handler, 0);
  
  writeMSR(0x174, __KERNEL_CS);
  writeMSR(0x175, INITIAL_ESP);
  writeMSR(0x176, (long)syscall_handler_sysenter);
  
  set_idt_reg(&idtR);
}

void keyboard_routine(){
  unsigned char pv = inb(0x60);
  // 0x80 = 10000000
  // 0x80 & 00000000 = 0 // Make
  // 0x80 & 10000000 = 1 // Break
  int isbreak = pv & 0x80;
  if(isbreak == 0){ // isbreak == false -> make
    char toprint = char_map[pv & 0x7F];
    if (toprint != '\0') {
      //printc_xy(70, 20, toprint); // para debugar
      kbd_buf_write(toprint);     // metemos el caracter en el buffer circular
    }
  }
}

void clock_routine(void) {
	zeos_ticks += 1;
	if (zeos_ticks % 18 == 0) zeos_show_clock();

  schedule(); //IMPLEMENTAR Y DESCOMENTAR CUANDO SE TENGA EN CUENTA EL QUANTUM

  //Test Task_switch()
  /*static int turno_actual = 0;
  // Usamos un solo intervalo fijo (Quantum). Por ejemplo, 1000 ticks.
  if (zeos_ticks % 1000 == 0) {
      
      // Si actualmente estamos en init (0), cambiamos a idle (1)
      if (turno_actual == 0) {
          printk("Cambiando a idle...\n");
          turno_actual = 1; // Actualizamos el estado antes del cambio
          task_switch((union task_union*)idle_task);
      } 
      // Si actualmente estamos en idle (1), cambiamos a init (0)
      else {
          printk("Cambiando a init...\n");
          turno_actual = 0; // Actualizamos el estado antes del cambio
          task_switch((union task_union*)init_task);
      }
  }*/

}

void pagefault_routine(int eip) {
	printk("\n");
	printk("Process generates a PAGE FAULT exception at EIP: 0x");
	char buff[10];
	itoa_hexadecimal(eip, buff);
	printk(buff);
	printk("\n");
	while(1);
}
